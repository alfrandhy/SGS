import React from 'react';
import { Link } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';

export default function BoqDetail({  auth, boq, className = '' }) {
    if (!boq) {
        return (
            <div className="container mx-auto p-4">
                <p>BOQ details not available.</p>
                <Link href={route('boqs.index')} className="inline-flex items-center px-4 py-2 bg-yellow-400 hover:bg-yellow-500 text-gray-700 rounded-md mt-4">
                    Back to BOQs
                </Link>
            </div>
        );
    }

    return (
        <div className="container mx-auto p-4">
            <Link href={route('boqs.index')} className="inline-flex items-center px-4 py-2 bg-yellow-400 hover:bg-yellow-500 text-gray-700 rounded-md mb-4">
                Back to BOQs
            </Link>

            <h1 className="text-2xl font-bold mb-6">BOQ Detail View</h1>

            <div className="space-y-4 max-w-xl">

                <div>
                    <label className="block font-medium text-gray-700">BOQ Code</label>
                    <p className="mt-1 text-gray-900">{boq.boqcode}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Project Code</label>
                    <p className="mt-1 text-gray-900">{boq.projectcode}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Part No</label>
                    <p className="mt-1 text-gray-900">{boq.partno}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Description</label>
                    <p className="mt-1 whitespace-pre-wrap text-gray-900">{boq.description}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Details</label>
                    <p className="mt-1 whitespace-pre-wrap text-gray-900">{boq.detail}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Dimension</label>
                    <p className="mt-1 text-gray-900">{boq.dimension}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Material</label>
                    <p className="mt-1 text-gray-900">{boq.material}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Quantity</label>
                    <p className="mt-1 text-gray-900">{boq.qty}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Unit</label>
                    <p className="mt-1 text-gray-900">{boq.unit}</p>
                </div>

                <div>
                    <label className="block font-medium text-gray-700">Type</label>
                    <p className="mt-1 text-gray-900">{boq.type}</p>
                </div>

            </div>
        </div>
    );
}
