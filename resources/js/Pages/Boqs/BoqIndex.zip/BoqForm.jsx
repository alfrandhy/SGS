import { useState, React, useEffect } from 'react';
import { useForm, Head, Link } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import PrimaryButton from '@/Components/PrimaryButton';
import { Transition } from '@headlessui/react';
import InputLabel from '@/Components/InputLabel';
import TextInput from '@/Components/TextInput';
import InputError from '@/Components/InputError';

export default function BoqForm({ auth, boq, className = '', errors = {} }) {
    const [error, setError] = useState(null);

    const isDisabled = boq ? true : false;

    const { data, setData, post, put, processing, recentlySuccessful, reset } = useForm({
        boqcode: boq?.boqcode || '',
        projectcode: boq?.projectcode || '',
        partno: boq?.partno || '',
        description: boq?.description || '',
        detail: boq?.detail || '',
        dimension: boq?.dimension || '',
        material: boq?.material || '',
        qty: boq?.qty || '',
        unit: boq?.unit || '',
        type: boq?.type || '',
    });

    useEffect(() => {
        if (!boq) { // Only auto-generate for new record
            setData('boqcode', `${data.projectcode}_${data.partno}`);
        }
    }, [data.projectcode, data.partno]);

    const UNIT_OPTIONS = [
        { value: 'pc', label: 'Piece' },
        { value: 'pcs', label: 'Pieces' },
        { value: 'm', label: 'Meter' },
        { value: 'kg', label: 'Kilogram' },
        { value: 'set', label: 'Set' },
        { value: 'lot', label: 'Lot' },
    ];

    const TYPE_OPTIONS = [
        { value: 'material', label: 'Material' },
        { value: 'labor', label: 'Labor / Jasa' },
        { value: 'construction', label: 'Construction' },
    ];


    const handleSubmit = (e) => {
        e.preventDefault();
        // console.log('Submitting form with data:', data);

        if (boq) {
            // Update existing BOQ by ID
            put(route('boqs.update', boq.id));
        } else {
            try {
                post(route('boqs.store'),  // Make sure this route exists
                    {
                        boqcode: data.projectcode + '_' + data.partno,
                        projectcode: data.projectcode,
                        partno: data.partno,
                        description: data.description,
                        detail: data.detail,
                        dimension: data.dimension,
                        material: data.material,
                        qty: data.qty,
                        unit: data.unit,
                        type: data.type,
                    },
                    {
                        onSuccess: () => reset(),
                    }
                );
            }
            catch (error) {
                console.log('Error creating BOQ:', error);
            }
        }
    };


    return (
        <div className="container mx-auto">
            <Link href={route('boqs.index')} className="inline-flex items-center px-4 py-2 bg-yellow-400 hover:bg-yellow-500 text-gray-700 rounded-md mb-4">
                Back to BOQs
            </Link>

            <h1 className="text-2xl font-bold">{boq ? 'Edit BOQ' : 'Add New BOQ'}</h1>
            <form onSubmit={handleSubmit}>
                {error && <div className="alert alert-danger">{error}</div>}
                <InputLabel htmlFor="boqcode" value="BOQ Code" />
                <TextInput id="boqcode" type="text" value={boq ? data.boqcode : `${data.projectcode}_${data.partno}`} onChange={(e) => setData('boqcode', e.target.value)} placeholder="BOQ Code" required disabled />
                <InputError className="mt-2" message={errors.boqcode} />

                <InputLabel htmlFor="projectcode" value="Project Code" />
                <TextInput id="projectcode" type="text" value={data.projectcode} onChange={(e) => setData('projectcode', e.target.value)} placeholder="Project Code" required disabled={!!boq} />
                <InputError className="mt-2" message={errors.projectcode} />

                <InputLabel htmlFor="partno" value="Part No" />
                <TextInput id="partno" type="text" value={data.partno} onChange={(e) => setData('partno', e.target.value)} placeholder="Part No" required disabled={!!boq} />
                <InputError className="mt-2" message={errors.partno} />

                <InputLabel htmlFor="description" value="Description" />
                <textarea id="description" value={data.description} onChange={(e) => setData('description', e.target.value)} placeholder="Description" required></textarea>
                <InputError className="mt-2" message={errors.description} />

                <InputLabel htmlFor="detail" value="Details" />
                <textarea id="detail" value={data.detail} onChange={(e) => setData('detail', e.target.value)} placeholder="Details"></textarea>
                <InputError className="mt-2" message={errors.detail} />

                <InputLabel htmlFor="dimension" value="Dimension" />
                <TextInput id="dimension" type="text" value={data.dimension} onChange={(e) => setData('dimension', e.target.value)} placeholder="Dimension" />
                <InputError className="mt-2" message={errors.dimension} />

                <InputLabel htmlFor="material" value="Material" />
                <TextInput id="material" type="text" value={data.material} onChange={(e) => setData('material', e.target.value)} placeholder="Material" />
                <InputError className="mt-2" message={errors.material} />

                <InputLabel htmlFor="qty" value="Quantity" />
                <TextInput id="qty" type="number" value={data.qty} onChange={(e) => setData('qty', parseInt(e.target.value, 10) || '')} placeholder="Quantity" required />
                <InputError className="mt-2" message={errors.qty} />

                <InputLabel htmlFor="unit" value="Unit" />
                <select id="unit" value={data.unit} onChange={(e) => setData('unit', e.target.value)} required>
                    <option value="">Select unit</option>
                    {UNIT_OPTIONS.map(({ value, label }) => (
                        <option key={value} value={value}>
                            {label}
                        </option>
                    ))}
                </select>
                <InputError className="mt-2" message={errors.unit} />

                <InputLabel htmlFor="type" value="Type" />
                <select id="type" value={data.type} onChange={(e) => setData('type', e.target.value)} required>
                    <option value="">Select type</option>
                    {TYPE_OPTIONS.map(({ value, label }) => (
                        <option key={value} value={value}>
                            {label}
                        </option>
                    ))}
                </select>
                <InputError className="mt-2" message={errors.type} />

                <div className="flex items-center gap-4">
                    <PrimaryButton
                        bgColor='bg-gray-800'
                        textColor='text-white'
                        disabled={processing}>
                        {boq ? 'Update' : 'Save'}
                    </PrimaryButton>

                    <PrimaryButton
                        bgColor='bg-blue-800'
                        bgFocusColor='focus:bg-blue-700'
                        bgHoverColor='hover:bg-blue-700'
                        bgActiveColor='active:bg-blue-900'
                        textColor='text-white'
                        type="button" onClick={() => reset()} disabled={processing}>
                        Reset
                    </PrimaryButton>

                    <Transition
                        show={recentlySuccessful}
                        enter="transition ease-in-out"
                        enterFrom="opacity-0"
                        leave="transition ease-in-out"
                        leaveTo="opacity-0"
                    >
                        <p className="text-sm text-gray-600">Saved.</p>
                    </Transition>
                </div>

            </form>
        </div>
    );
};
