import React, { useState } from "react";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, Link, useForm } from "@inertiajs/react";

export default function BoqIndex({ auth, boqs }) {
    const { delete: destroy } = useForm();
    const [filterText, setFilterText] = useState("");

    // Filter boqs before grouping, case insensitive match against multiple fields
    const filteredBoqs = boqs.filter(
        (boq) =>
            boq.projectcode.toLowerCase().includes(filterText.toLowerCase()) ||
            boq.partno.toLowerCase().includes(filterText.toLowerCase()) ||
            boq.description.toLowerCase().includes(filterText.toLowerCase()) ||
            boq.type.toLowerCase().includes(filterText.toLowerCase())
    );

    const handleDelete = (boqcode) => {
        if (!window.confirm("Delete this BOQ?")) return;

        destroy(route('boqs.destroy', boqcode), {
            onSuccess: () => {
                // Inertia will automatically update the page with new data
            },
            onError: (errors) => {
                alert("Error deleting BOQ: " + (errors.message || "Unknown error occurred"));
            },
        });
    };

    // Group by projectcode
    const groupedBoqs = filteredBoqs.reduce((groups, boq) => {
        (groups[boq.projectcode] = groups[boq.projectcode] || []).push(boq);
        return groups;
    }, {});

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <h2 className="font-semibold text-xl text-gray-800 leading-tight">
                    Boq
                </h2>
            }
        >
            <Head title="Boq" />

            <div className="py-4">
                <div className="max-w-9xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 bg-white border-b border-gray-200">
                            <h1 className="text-2xl font-bold mb-4">
                                Welcome to the BOQ Dashboard
                            </h1>
                            <p className="mb-4">
                                This is your central hub for managing Bills of
                                Quantities (BOQs).
                            </p>
                            <p className="mb-4">
                                You can view, create, edit, and delete BOQs from
                                here.
                            </p>
                            <p className="mb-4">
                                Use the navigation links to access different
                                sections.
                            </p>
                        </div>
                        <div className="flex justify-between items-center p-4 bg-white border-b border-gray-200">
                            <Link
                                href={route("boqs.create")}
                                className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md"
                            >
                                Add New BOQ
                            </Link>
                        </div>
                        <div className="block rounded p-6 bg-white border-b border-gray-200">
                            {/* Filter Input */}
                            <div className="mb-4">
                                <input
                                    type="text"
                                    placeholder="Filter by project, part no, description or type"
                                    value={filterText}
                                    onChange={(e) =>
                                        setFilterText(e.target.value)
                                    }
                                    className="border p-2 rounded w-full sm:w-1/2"
                                />
                            </div>
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Project Code
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Part No
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Description
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Material
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Dimension
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Qty
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Unit
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Type
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Actions
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Object.entries(groupedBoqs).length ===
                                        0 && (
                                        <tr>
                                            <td
                                                colSpan={9}
                                                className="text-center py-4"
                                            >
                                                No BOQs found.
                                            </td>
                                        </tr>
                                    )}
                                    {Object.entries(groupedBoqs).map(
                                        ([projectcode, boqs]) => (
                                            <React.Fragment key={projectcode}>
                                                {/* Group header row */}
                                                <tr className="bg-gray-200">
                                                    <td
                                                        colSpan={9}
                                                        className="px-6 py-2 font-semibold"
                                                    >
                                                        Project Code:{" "}
                                                        {projectcode}
                                                    </td>
                                                </tr>
                                                {/* BOQ rows for this project */}
                                                {boqs.map((boq, index) => (
                                                    <tr
                                                        key={
                                                            boq.boqcode ||
                                                            `${projectcode}-${index}`
                                                        }
                                                        className="hover:bg-gray-100"
                                                    >
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.boqcode}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.partno}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.description}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.material}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.dimension}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.qty}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.unit}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {boq.type}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <Link
                                                                href={`boqs/${boq.boqcode}`}
                                                                className="text-blue-600 hover:text-blue-900"
                                                            >
                                                                View
                                                            </Link>{" "}
                                                            |{" "}
                                                            <Link
                                                                href={`boqs/${boq.boqcode}/edit`}
                                                                className="text-blue-600 hover:text-blue-900"
                                                            >
                                                                Edit
                                                            </Link>{" "}
                                                            |{" "}
                                                            <button
                                                                onClick={() =>
                                                                    handleDelete(
                                                                        boq.boqcode
                                                                    )
                                                                }
                                                                className="text-red-600 hover:text-red-900"
                                                            >
                                                                Delete
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </React.Fragment>
                                        )
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
